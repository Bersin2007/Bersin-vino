document.addEventListener('DOMContentLoaded', function () {
  var burger = document.getElementById('navburger');
  var panel = document.getElementById('mobilePanel');
  if (burger && panel) {
    burger.addEventListener('click', function () {
      panel.classList.toggle('open');
    });
  }
});
