(function () {
  var fleetGrid = document.getElementById('fleetGrid');
  if (!fleetGrid) return; // this page doesn't include the live dashboard

  var NODES = ["rhel-node-01", "rhel-node-02", "rhel-node-03", "rhel-node-04", "rhel-node-05", "rhel-node-06"];
  var HIST_LEN = 24;

  var state = {};
  NODES.forEach(function (id, i) {
    var mode = i === 1 ? "leak" : (i === 3 ? "disk" : "healthy");
    state[id] = {
      mode: mode,
      cpu: 25 + Math.random() * 15,
      mem: 35 + Math.random() * 15,
      disk: 45 + Math.random() * 10,
      cpuHist: [], memHist: [], diskHist: [],
      status: "ok",
      errLogs: 0
    };
    for (var j = 0; j < HIST_LEN; j++) {
      state[id].cpuHist.push(state[id].cpu);
      state[id].memHist.push(state[id].mem);
      state[id].diskHist.push(state[id].disk);
    }
  });

  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

  function stepNode(s) {
    s.cpu = clamp(s.cpu + (Math.random() - 0.5) * 6, 8, 97);
    if (s.mode === "leak") {
      s.mem = clamp(s.mem + Math.random() * 1.8, 0, 99);
    } else {
      s.mem = clamp(s.mem + (Math.random() - 0.52) * 3, 20, 80);
    }
    if (s.mode === "disk") {
      s.disk = clamp(s.disk + Math.random() * 1.1, 0, 99);
    } else {
      s.disk = clamp(s.disk + (Math.random() - 0.5) * 0.6, 30, 70);
    }
    s.errLogs = Math.random() < 0.08 ? Math.floor(Math.random() * 4) : 0;

    s.cpuHist.push(s.cpu); s.cpuHist.shift();
    s.memHist.push(s.mem); s.memHist.shift();
    s.diskHist.push(s.disk); s.diskHist.shift();

    if (s.mem > 90 || s.disk > 90) s.status = "crit";
    else if (s.mem > 78 || s.disk > 78 || s.errLogs > 2) s.status = "warn";
    else s.status = "ok";
  }

  function sparkPath(hist) {
    var w = 100, h = 30;
    var min = Math.min.apply(null, hist), max = Math.max.apply(null, hist);
    var range = (max - min) || 1;
    return hist.map(function (v, i) {
      var x = (i / (hist.length - 1)) * w;
      var y = h - ((v - min) / range) * h;
      return (i === 0 ? "M" : "L") + x.toFixed(1) + "," + y.toFixed(1);
    }).join(" ");
  }

  var sparkColor = { ok: "#3DD68C", warn: "#F5A623", crit: "#FF5C5C" };

  function renderFleet() {
    fleetGrid.innerHTML = "";
    NODES.forEach(function (id) {
      var s = state[id];
      var card = document.createElement('div');
      card.className = "node-card";
      card.innerHTML =
        '<div class="node-top">' +
        '<div class="node-name">' + id + '</div>' +
        '<div class="badge ' + s.status + '">' + (s.status === 'ok' ? 'healthy' : s.status === 'warn' ? 'watch' : 'critical') + '</div>' +
        '</div>' +
        '<div class="metric-row"><span>cpu</span><b>' + s.cpu.toFixed(0) + '%</b></div>' +
        '<div class="metric-row"><span>mem</span><b>' + s.mem.toFixed(0) + '%</b></div>' +
        '<div class="metric-row"><span>disk</span><b>' + s.disk.toFixed(0) + '%</b></div>' +
        '<svg class="spark" viewBox="0 0 100 30" preserveAspectRatio="none">' +
        '<path d="' + sparkPath(s.memHist) + '" fill="none" stroke="' + sparkColor[s.status] + '" stroke-width="1.6" vector-effect="non-scaling-stroke"/>' +
        '</svg>' +
        '<div class="node-foot">last check: just now</div>';
      fleetGrid.appendChild(card);
    });

    var ok = 0, warn = 0, crit = 0;
    NODES.forEach(function (id) {
      if (state[id].status === "ok") ok++;
      else if (state[id].status === "warn") warn++;
      else crit++;
    });
    var elOk = document.getElementById('ledOk');
    var elWarn = document.getElementById('ledWarn');
    var elCrit = document.getElementById('ledCrit');
    if (elOk) elOk.textContent = ok;
    if (elWarn) elWarn.textContent = warn;
    if (elCrit) elCrit.textContent = crit;
    var statusOut = document.getElementById('statusOut');
    if (statusOut) {
      statusOut.innerHTML = 'FLEET STATUS: ' + NODES.length + ' nodes monitored | ' + (warn + crit) +
        ' alert' + ((warn + crit) !== 1 ? 's' : '') + ' active | model v1 (IsolationForest + GBM)<span class="cursor"></span>';
    }
  }

  var alertsList = document.getElementById('alertsList');
  var alertCount = document.getElementById('alertCount');
  var activeAlerts = 0;
  var recentlyAlerted = {};

  function pushAlert(id, s) {
    if (!alertsList) return;
    var now = Date.now();
    if (recentlyAlerted[id] && now - recentlyAlerted[id] < 15000) return;
    recentlyAlerted[id] = now;

    var reason;
    if (s.mem > 90) reason = 'memory at ' + s.mem.toFixed(0) + '% <span style="color:var(--text-faint)">(possible leak)</span>';
    else if (s.disk > 90) reason = 'disk at ' + s.disk.toFixed(0) + '% <span style="color:var(--text-faint)">(filling up)</span>';
    else reason = 'elevated error-log rate';

    var li = document.createElement('li');
    li.className = "alert-item " + s.status;
    var t = new Date().toLocaleTimeString();
    li.innerHTML = '<i></i><div class="txt"><b>' + id + '</b> — ' + reason + '<div class="ts">' + t + '</div></div>';
    alertsList.prepend(li);
    while (alertsList.children.length > 30) alertsList.removeChild(alertsList.lastChild);

    activeAlerts++;
    if (alertCount) alertCount.textContent = activeAlerts;
  }

  var logBody = document.getElementById('logBody');
  var infoMsgs = ["systemd: Started session", "kernel: link becomes ready", "sshd: Accepted publickey", "chronyd: synchronised to NTP", "sar: sample collected"];
  var warnMsgs = ["kernel: TCP: request_sock_TCP: Possible SYN flooding", "systemd: unit exceeded memory watermark", "sar: disk io wait elevated"];
  var errMsgs = ["kernel: Out of memory: Killed process", "systemd: Main process exited, code=killed", "sshd: error: fatal I/O error", "kernel: EXT4-fs error: filesystem full"];

  function pushLog(id, level, msg) {
    if (!logBody) return;
    var line = document.createElement('div');
    line.className = "log-line lvl-" + level;
    var t = new Date().toISOString().split('T')[1].slice(0, 8);
    line.innerHTML = '<span style="color:var(--text-faint)">' + t + '</span><span class="lvl">[' + level + ']</span><span class="host">' + id + '</span> ' + msg;
    logBody.appendChild(line);
    while (logBody.children.length > 60) logBody.removeChild(logBody.firstChild);
    logBody.scrollTop = logBody.scrollHeight;
  }

  function tick() {
    NODES.forEach(function (id) { stepNode(state[id]); });
    renderFleet();

    NODES.forEach(function (id) {
      var s = state[id];
      if (s.status === "crit" || s.status === "warn") pushAlert(id, s);
    });

    var id = NODES[Math.floor(Math.random() * NODES.length)];
    var s = state[id];
    if (s.status === "crit" && Math.random() < 0.7) {
      pushLog(id, "ERR", errMsgs[Math.floor(Math.random() * errMsgs.length)]);
    } else if (s.status === "warn" && Math.random() < 0.5) {
      pushLog(id, "WARN", warnMsgs[Math.floor(Math.random() * warnMsgs.length)]);
    } else if (Math.random() < 0.6) {
      pushLog(id, "INFO", infoMsgs[Math.floor(Math.random() * infoMsgs.length)]);
    }
  }

  renderFleet();
  for (var i = 0; i < 10; i++) tick();
  setInterval(tick, 1800);
})();
